import cv2,numpy as np,logging,time,os,smtplib,serial,pynmea2,easyocr,mimetypes,subprocess
from math import radians, sin, cos, sqrt, atan2
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google.oauth2 import service_account
from threading import Thread
from ultralytics import YOLO

# Configuration
CAMERA_RESOLUTION = (1280, 720)
FRAME_RATE = 30
SPEED_LIMIT_KMH = 120  # Updated to match project features
VIDEO_SAVE_PATH = "videos/traffic_video.avi"
SNIPPET_PATH = "videos/violation_snippet.h264"
MAX_VIDEO_SIZE_MB = 2

# GPS Configuration
GPS_PORT = "/dev/ttyACM0"
GPS_BAUDRATE = 9600

# Email Configuration
SENDER_EMAIL = "drone.2023.gp@gmail.com"
RECEIVER_EMAIL = "test._999@outlook.com"
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

# Google Drive Configuration
DRIVE_CREDENTIALS = "credentials.json"
DRIVE_FOLDER_ID = None  # Optional: Add specific folder ID

# Model Paths
VEHICLE_MODEL_PATH = "yolov8n.pt"

# Initialize components
ocr_reader = easyocr.Reader(['en'])
vehicle_model = YOLO(VEHICLE_MODEL_PATH)

def setup_logging():
    """Configure logging settings"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler('traffic_monitor.log'),
            logging.StreamHandler()
        ]
    )

class DroneCamera:
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.cap = None
        self.video_writer = None
        self.last_violation_time = 0
        self.recording = False

    def initialize(self):
        """Initialize camera and video writer"""
        try:
            self.cap = cv2.VideoCapture(0)
            if not self.cap.isOpened():
                raise RuntimeError("Camera not found")
            
            self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, CAMERA_RESOLUTION[0])
            self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, CAMERA_RESOLUTION[1])
            self.cap.set(cv2.CAP_PROP_FPS, FRAME_RATE)
            
            fourcc = cv2.VideoWriter_fourcc(*'XVID')
            self.video_writer = cv2.VideoWriter(
                VIDEO_SAVE_PATH, fourcc, FRAME_RATE, CAMERA_RESOLUTION)
            
            self.logger.info("Camera initialized successfully")
            return True
        except Exception as e:
            self.logger.error(f"Camera initialization failed: {str(e)}")
            return False

    def read_frame(self):
        """Read a frame from the camera with error handling"""
        try:
            if not self.cap or not self.cap.isOpened():
                self.initialize()
            
            ret, frame = self.cap.read()
            if not ret:
                self.logger.warning("Failed to read frame. Reinitializing camera...")
                self.initialize()
                return False, None
            
            if self.video_writer is not None:
                self.video_writer.write(frame)
            
            return True, frame
        except Exception as e:
            self.logger.error(f"Error reading frame: {str(e)}")
            return False, None

    def start_violation_recording(self):
        """Start recording a violation snippet"""
        if not self.recording and (time.time() - self.last_violation_time) > 30:
            self.recording = True
            Thread(target=self._record_violation_snippet).start()

    def _record_violation_snippet(self):
        """Record 10-second violation snippet using libcamera-vid"""
        try:
            self.logger.info("Starting violation recording...")
            cmd = f"libcamera-vid -t 10000 -o {SNIPPET_PATH}"
            subprocess.run(cmd, shell=True, check=True)
            self.last_violation_time = time.time()
            self.logger.info("Violation snippet recorded")
        except subprocess.CalledProcessError as e:
            self.logger.error(f"Recording failed: {str(e)}")
        finally:
            self.recording = False

    def release(self):
        """Release resources"""
        if self.cap:
            self.cap.release()
        if self.video_writer:
            self.video_writer.release()

def read_gps():
    """Read GPS data with error handling"""
    try:
        with serial.Serial(GPS_PORT, GPS_BAUDRATE, timeout=1) as gps_serial:
            start_time = time.time()
            while time.time() - start_time < 5:  # 5-second timeout
                line = gps_serial.readline().decode('utf-8', errors='ignore').strip()
                if line.startswith("$GPRMC"):
                    msg = pynmea2.parse(line)
                    if msg.latitude != 0.0 and msg.longitude != 0.0:
                        return msg.latitude, msg.longitude
            logging.warning("GPS data timeout")
            return None, None
    except Exception as e:
        logging.error(f"GPS error: {str(e)}")
        return None, None

def haversine(lat1, lon1, lat2, lon2):
    """Calculate distance between two GPS points using Haversine formula"""
    R = 6371  # Earth radius in km
    lat1, lon1, lat2, lon2 = map(radians, [lat1, lon1, lat2, lon2])
    dlat = lat2 - lat1
    dlon = lon2 - lon1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * atan2(sqrt(a), sqrt(1-a))
    return R * c

def detect_vehicles(frame):
    """Detect vehicles using YOLOv8 model"""
    results = vehicle_model(frame, verbose=False)
    vehicles = []
    for box in results[0].boxes:
        class_id = int(box.cls)
        if vehicle_model.names[class_id] in ['car', 'truck', 'bus']:
            x1, y1, x2, y2 = map(int, box.xyxy[0])
            vehicles.append((x1, y1, x2-x1, y2-y1))
    return vehicles

def detect_license_plate(frame):
    """Detect and recognize license plates"""
    try:
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        plates = cv2.CascadeClassifier(
            cv2.data.haarcascades + "haarcascade_russian_plate_number.xml"
        ).detectMultiScale(gray, 1.1, 5)
        
        for (x, y, w, h) in plates:
            plate_roi = gray[y:y+h, x:x+w]
            plate_text = ocr_reader.readtext(plate_roi, detail=0)
            if plate_text:
                return " ".join(plate_text), (x, y, w, h)
        return None, None
    except Exception as e:
        logging.error(f"License plate detection failed: {str(e)}")
        return None, None

def send_email(plate_number, video_path):
    """Send email notification with video attachment or Drive link"""
    try:
        msg = MIMEMultipart()
        msg['From'] = SENDER_EMAIL
        msg['To'] = RECEIVER_EMAIL
        msg['Subject'] = "Traffic Violation Alert"
        
        body = f"""Traffic violation detected:
        - License Plate: {plate_number}
        - Time: {time.strftime('%Y-%m-%d %H:%M:%S')}
        """
        
        msg.attach(MIMEText(body, 'plain'))
        file_size = os.path.getsize(video_path)
        
        if file_size <= MAX_VIDEO_SIZE_MB * 1024 * 1024:
            with open(video_path, 'rb') as f:
                part = MIMEBase('application', 'octet-stream')
                part.set_payload(f.read())
                encoders.encode_base64(part)
                part.add_header('Content-Disposition', 
                              f'attachment; filename="{os.path.basename(video_path)}"')
                msg.attach(part)
        else:
            drive_link = upload_to_google_drive(video_path)
            msg.attach(MIMEText(f"\nVideo available at: {drive_link}", 'plain'))
        
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SENDER_EMAIL, os.environ['SMTP_PASSWORD'])
            server.send_message(msg)
            logging.info("Email notification sent")
    except Exception as e:
        logging.error(f"Failed to send email: {str(e)}")

def upload_to_google_drive(file_path):
    """Upload file to Google Drive and return shareable link"""
    try:
        creds = service_account.Credentials.from_service_account_file(
            DRIVE_CREDENTIALS,
            scopes=['https://www.googleapis.com/auth/drive']
        )
        
        service = build('drive', 'v3', credentials=creds)
        file_metadata = {
            'name': os.path.basename(file_path),
            'parents': [DRIVE_FOLDER_ID] if DRIVE_FOLDER_ID else []
        }
        
        media = MediaFileUpload(file_path, mimetype=mimetypes.guess_type(file_path)[0])
        file = service.files().create(
            body=file_metadata,
            media_body=media,
            fields='id'
        ).execute()
        
        service.permissions().create(
            fileId=file['id'],
            body={'type': 'anyone', 'role': 'reader'}
        ).execute()
        
        return f"https://drive.google.com/file/d/{file['id']}/view"
    except Exception as e:
        logging.error(f"Google Drive upload failed: {str(e)}")
        return None

def main():
    setup_logging()
    camera = DroneCamera()
    
    if not camera.initialize():
        logging.error("Failed to initialize camera. Exiting...")
        return
    
    prev_gps = None
    prev_time = time.time()
    violation_active = False
    
    try:
        while True:
            ret, frame = camera.read_frame()
            if not ret:
                continue
            
            # Vehicle detection
            vehicles = detect_vehicles(frame)
            current_gps = read_gps()
            
            # Process each detected vehicle
            for (x, y, w, h) in vehicles:
                # Get speed calculation
                if current_gps and prev_gps:
                    current_time = time.time()
                    time_diff = current_time - prev_time
                    distance = haversine(*prev_gps, *current_gps)
                    speed = (distance / time_diff) * 3600  # km/h
                    
                    # Detect license plate
                    plate_number, plate_bbox = detect_license_plate(frame)
                    
                    # Overlay information
                    color = (0, 0, 255) if speed > SPEED_LIMIT_KMH else (0, 255, 0)
                    cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
                    
                    # Add text overlays
                    cv2.putText(frame, f"{speed:.1f} km/h", (x, y-10),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
                    if plate_number:
                        cv2.putText(frame, plate_number, (x, y+h+20),
                                   cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,255), 2)
                    
                    # Handle violations
                    if speed > SPEED_LIMIT_KMH and plate_number and not violation_active:
                        logging.info(f"Violation detected: {plate_number} @ {speed:.1f} km/h")
                        camera.start_violation_recording()
                        Thread(target=send_email, args=(plate_number, SNIPPET_PATH)).start()
                        violation_active = True
                    else:
                        violation_active = False
                
                prev_gps = current_gps
                prev_time = time.time()
            
            # Display real-time feed
            cv2.imshow('Traffic Monitoring', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
    
    except KeyboardInterrupt:
        logging.info("Shutting down...")
    finally:
        camera.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    main()


"""
Requirements:
	•	Install required packages:
pip install opencv-python numpy pynmea2 easyocr ultralytics google-auth google-api-python-client
	•	Set environment variables:
export SMTP_PASSWORD='your-gmail-app-password'
	•	Add Google Drive service account credentials in credentials.json





Step 1: Save the Code on Your Computer
	•	Create a Project Folder:
	•	Create a folder on your computer to store all project files. For example:
mkdir ~/drone_traffic_monitoring
cd ~/drone_traffic_monitoring
	•	Save the Python Code:
	•	Create a Python file named traffic_monitor.py in the project folder.
	•	Copy and paste the provided Python code into this file.
	•	Save Additional Files:
	•	Google Drive Credentials:
	•	Save your Google Drive API credentials file as credentials.json in the project folder.
	•	YOLOv8 Model:
	•	Download the YOLOv8 model (yolov8n.pt) and place it in the project folder.
	•	Haar Cascade for License Plates:
	•	Ensure the Haar cascade file (haarcascade_russian_plate_number.xml) is available in the OpenCV data directory or download it and place it in the project folder.

Step 2: Install Required Software
	•	Install Python and Pip:
	•	Ensure Python 3.7+ is installed. Install it using:
sudo apt update
sudo apt install python3 python3-pip
	•	Install Required Libraries:
	•	Install the required Python libraries using pip:
pip install opencv-python numpy pynmea2 easyocr ultralytics google-auth google-api-python-client
	•	Install libcamera-vid:
	•	Install libcamera-vid for video recording:
sudo apt install libcamera-apps
	•	Set Environment Variables:
	•	Set the SMTP password as an environment variable:
export SMTP_PASSWORD='your-gmail-app-password'

Step 3: Hardware Setup
	•	Raspberry Pi 5 Setup:
	•	Install Raspberry Pi OS (64-bit) on your Raspberry Pi 5.
	•	Connect the Raspberry Pi to the internet.
	•	Camera Setup:
	•	Mount the AI camera on the drone.
	•	Connect the camera to the Raspberry Pi using the CSI or USB interface.
	•	Test the camera using:
libcamera-hello
	•	GPS Module Setup:
	•	Connect the u-blox GPS module to the Raspberry Pi via USB or UART.
	•	Ensure the GPS module is recognized by the system:
ls /dev/tty*
	•	Update the GPS_PORT variable in the code if necessary.
	•	Power Supply:
	•	Use a stable power supply for the Raspberry Pi and drone.
	•	Display Setup:
	•	Connect a monitor to the Raspberry Pi for real-time display.

Step 4: Run the Code
	•	Navigate to the Project Folder:
cd ~/drone_traffic_monitoring
	•	Run the Python Script:
python3 traffic_monitor.py
	•	Monitor Logs:
	•	Check the logs in traffic_monitor.log for debugging and system status.

Step 5: Align Hardware with Code
	•	Camera Alignment:
	•	Ensure the camera is pointed at the road and has a clear view of vehicles.
	•	Adjust the camera angle and focus for optimal vehicle detection.
	•	GPS Module Alignment:
	•	Place the GPS module in an open area for better satellite reception.
	•	Ensure the GPS module is securely connected to the Raspberry Pi.
	•	Drone Positioning:
	•	Fly the drone at a height that provides a clear view of the road.
	•	Ensure the drone is stable and maintains its position during operation.
	•	Real-Time Display:
	•	Connect the Raspberry Pi to a monitor or use VNC for remote viewing.

Step 6: Test the System
	•	Test Vehicle Detection:
	•	Drive a vehicle through the monitored area and check if it is detected.
	•	Test Speed Calculation:
	•	Verify that the system accurately calculates vehicle speed using GPS data.
	•	Test License Plate Recognition:
	•	Ensure the system correctly detects and recognizes license plates.
	•	Test Email Notifications:
	•	Trigger a speed violation and verify that an email is sent with the correct details.
	•	Test Video Recording:
	•	Check that the main video and violation snippets are saved correctly.

Step 7: Optimize and Deploy
	•	Optimize Performance:
	•	Use hardware acceleration (e.g., OpenCV with V4L2) for better performance.
	•	Quantize the YOLOv8 model for faster inference.
	•	Deploy on Drone:
	•	Transfer the project folder to the Raspberry Pi on the drone.
	•	Run the script on the drone and monitor its performance.
	•	Automate Startup:
	•	Add the script to startup so it runs automatically when the Raspberry Pi boots:
sudo nano /etc/rc.local
	•	Add the following line before exit 0:
python3 /home/pi/drone_traffic_monitoring/traffic_monitor.py &

File Structure
Copy
drone_traffic_monitoring/
├── traffic_monitor.py         			 # Main Python script
├── credentials.json          	 	 	# Google Drive API credentials
├── yolov8n.pt               	 	  	# YOLOv8 model
├── traffic_monitor.log      	   		# Log file
├── videos/                    				 # Directory for saved videos
│   ├── traffic_video.avi       		# Main video recording
│   └── violation_snippet.h264 		 # Violation snippets

Troubleshooting
	•	Camera Not Working:
	•	Check camera connections and permissions.
	•	Test the camera using libcamera-hello.
	•	GPS Not Detected:
	•	Verify the GPS module is connected to the correct port.
	•	Check GPS data using gpsmon.
	•	Email Not Sent:
	•	Verify the SMTP password is set correctly.
	•	Check Gmail settings for app password permissions.
	•	Performance Issues:
	•	Reduce camera resolution or frame rate.
	•	Use a lighter model (e.g., YOLOv8n).

"""